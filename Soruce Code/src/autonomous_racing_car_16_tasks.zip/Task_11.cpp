// TASK 11 - OBSTACLE AVOIDANCE DECISION
#include <Arduino.h>

const float SAFE=50;
float leftDistance=200,rightDistance=100,frontDistance=40;

int chooseDirection(){
    if(leftDistance>SAFE && leftDistance>rightDistance)return -1;
    if(rightDistance>SAFE && rightDistance>leftDistance)return 1;
    if(leftDistance>SAFE)return -1;
    if(rightDistance>SAFE)return 1;
    return 0;
}
void setup(){Serial.begin(115200);Serial.println("TASK 11: Avoidance decision");}
void loop(){
    int d=chooseDirection();
    if(d<0)Serial.println("Choose LEFT");
    else if(d>0)Serial.println("Choose RIGHT");
    else Serial.println("STOP - no safe direction");
    delay(1000);
}

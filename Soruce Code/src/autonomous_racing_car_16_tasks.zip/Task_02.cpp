// TASK 02 - L298N MOTOR CONTROL
#include <Arduino.h>

const int LEFT_IN1 = 5, LEFT_IN2 = 6, LEFT_PWM = 7;
const int RIGHT_IN1 = 9, RIGHT_IN2 = 10, RIGHT_PWM = 8;

void stopMotors() {
    ledcWrite(LEFT_PWM, 0);
    ledcWrite(RIGHT_PWM, 0);
    digitalWrite(LEFT_IN1, LOW); digitalWrite(LEFT_IN2, LOW);
    digitalWrite(RIGHT_IN1, LOW); digitalWrite(RIGHT_IN2, LOW);
}
void forward(int speed) {
    digitalWrite(LEFT_IN1,HIGH); digitalWrite(LEFT_IN2,LOW);
    digitalWrite(RIGHT_IN1,HIGH); digitalWrite(RIGHT_IN2,LOW);
    ledcWrite(LEFT_PWM,speed); ledcWrite(RIGHT_PWM,speed);
}
void reverseMotors(int speed) {
    digitalWrite(LEFT_IN1,LOW); digitalWrite(LEFT_IN2,HIGH);
    digitalWrite(RIGHT_IN1,LOW); digitalWrite(RIGHT_IN2,HIGH);
    ledcWrite(LEFT_PWM,speed); ledcWrite(RIGHT_PWM,speed);
}

void setup() {
    Serial.begin(115200);
    pinMode(LEFT_IN1,OUTPUT); pinMode(LEFT_IN2,OUTPUT);
    pinMode(RIGHT_IN1,OUTPUT); pinMode(RIGHT_IN2,OUTPUT);
    ledcAttach(LEFT_PWM,1000,8);
    ledcAttach(RIGHT_PWM,1000,8);
    stopMotors();
    Serial.println("TASK 02: Motor test");
}
void loop() {
    Serial.println("Forward"); forward(120); delay(2000);
    stopMotors(); delay(1000);
    Serial.println("Reverse"); reverseMotors(120); delay(2000);
    stopMotors(); delay(2000);
}

// TASK 03 - STEERING SERVO
#include <Arduino.h>
#include <ESP32Servo.h>

const int SERVO_PIN = 4;
const int CENTER = 90, LEFT = 55, RIGHT = 125;
Servo steering;

void setup() {
    Serial.begin(115200);
    steering.attach(SERVO_PIN);
    steering.write(CENTER);
    Serial.println("TASK 03: Steering test");
}
void loop() {
    Serial.println("LEFT"); steering.write(LEFT); delay(1500);
    Serial.println("CENTER"); steering.write(CENTER); delay(1000);
    Serial.println("RIGHT"); steering.write(RIGHT); delay(1500);
    Serial.println("CENTER"); steering.write(CENTER); delay(1000);
}

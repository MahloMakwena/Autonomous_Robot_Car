// TASK 06 - DISTANCE TRAVELLED
#include <Arduino.h>

const int LEFT_ENCODER=14, RIGHT_ENCODER=15;
const float TICKS_PER_REVOLUTION=20.0;
const float WHEEL_DIAMETER_MM=65.0;
const float CIRCUMFERENCE_MM=PI*WHEEL_DIAMETER_MM;
volatile long leftTicks=0,rightTicks=0;

void IRAM_ATTR leftISR(){leftTicks++;}
void IRAM_ATTR rightISR(){rightTicks++;}

void setup(){
    Serial.begin(115200);
    pinMode(LEFT_ENCODER,INPUT_PULLUP); pinMode(RIGHT_ENCODER,INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(LEFT_ENCODER),leftISR,RISING);
    attachInterrupt(digitalPinToInterrupt(RIGHT_ENCODER),rightISR,RISING);
    Serial.println("TASK 06: Distance test");
}
void loop(){
    static long pl=0,pr=0; static float distance=0; static unsigned long last=0;
    noInterrupts(); long l=leftTicks,r=rightTicks; interrupts();
    long dl=l-pl,dr=r-pr; pl=l;pr=r;
    distance += (((dl+dr)/2.0)/TICKS_PER_REVOLUTION*CIRCUMFERENCE_MM)/1000.0;
    if(millis()-last>=500){last=millis();Serial.printf("Distance: %.3f m\n",distance);}
    delay(10);
}

// TASK 12 - TURN DETECTION
#include <Arduino.h>

const float TURN_DISTANCE=150;
float frontDistance=120,leftDistance=250,rightDistance=100;

bool detectTurn(){
    return frontDistance<TURN_DISTANCE &&
           (leftDistance>frontDistance+20 || rightDistance>frontDistance+20);
}
void setup(){Serial.begin(115200);Serial.println("TASK 12: Turn detection");}
void loop(){
    Serial.println(detectTurn()?"TURN AHEAD":"NO TURN DETECTED");
    delay(1000);
}

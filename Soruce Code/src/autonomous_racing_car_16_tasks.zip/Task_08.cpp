// TASK 08 - RPLIDAR A1 UART COMMUNICATION
#include <Arduino.h>

const int LIDAR_RX=16,LIDAR_TX=17;
HardwareSerial LidarSerial(1);

void setup(){
    Serial.begin(115200);
    LidarSerial.begin(115200,SERIAL_8N1,LIDAR_RX,LIDAR_TX);
    Serial.println("TASK 08: RPLIDAR UART test");
}
void loop(){
    while(LidarSerial.available()){
        uint8_t b=LidarSerial.read();
        Serial.printf("%02X ",b);
    }
}

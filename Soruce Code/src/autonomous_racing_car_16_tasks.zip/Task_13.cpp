// TASK 13 - AUTONOMOUS STEERING
#include <Arduino.h>
#include <ESP32Servo.h>

const int SERVO_PIN=4; const int CENTER=90,LEFT=55,RIGHT=125;
Servo servo; float leftDistance=200,rightDistance=100;

void setup(){Serial.begin(115200);servo.attach(SERVO_PIN);servo.write(CENTER);Serial.println("TASK 13: Steering decision");}
void loop(){
    if(leftDistance>rightDistance){servo.write(LEFT);Serial.println("STEER LEFT");}
    else{servo.write(RIGHT);Serial.println("STEER RIGHT");}
    delay(1000);
}

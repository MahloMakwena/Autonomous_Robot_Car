// TASK 05 - WHEEL ENCODERS
#include <Arduino.h>

const int LEFT_ENCODER=14, RIGHT_ENCODER=15;
volatile long leftTicks=0, rightTicks=0;
void IRAM_ATTR leftISR(){leftTicks++;}
void IRAM_ATTR rightISR(){rightTicks++;}

void setup(){
    Serial.begin(115200);
    pinMode(LEFT_ENCODER,INPUT_PULLUP); pinMode(RIGHT_ENCODER,INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(LEFT_ENCODER),leftISR,RISING);
    attachInterrupt(digitalPinToInterrupt(RIGHT_ENCODER),rightISR,RISING);
    Serial.println("TASK 05: Encoder test");
}
void loop(){
    static unsigned long last=0;
    if(millis()-last>=500){
        last=millis();
        noInterrupts(); long l=leftTicks,r=rightTicks; interrupts();
        Serial.printf("Left ticks: %ld | Right ticks: %ld\n",l,r);
    }
}

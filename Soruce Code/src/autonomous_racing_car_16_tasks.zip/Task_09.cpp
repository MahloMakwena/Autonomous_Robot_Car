// TASK 09 - RPLIDAR A1 360-DEGREE DATA
// NOTE: This is the scan-frame test. Verify your A1 interface/protocol
// before using these readings for motor control.
#include <Arduino.h>

const int RX=16,TX=17; HardwareSerial LidarSerial(1);
float distanceAtAngle[360]; unsigned long stamp[360];

void setup(){
    Serial.begin(115200); LidarSerial.begin(115200,SERIAL_8N1,RX,TX);
    for(int i=0;i<360;i++){distanceAtAngle[i]=999;stamp[i]=0;}
    Serial.println("TASK 09: 360-degree LiDAR data");
}
void loop(){
    while(LidarSerial.available()){
        // Raw-byte monitoring is intentionally used here.
        // Add the verified A1 packet decoder for your exact interface.
        uint8_t b=LidarSerial.read();
        (void)b;
    }
    static unsigned long last=0;
    if(millis()-last>1000){
        last=millis();
        Serial.println("LiDAR data task running. Verify packet decoding before driving.");
    }
}

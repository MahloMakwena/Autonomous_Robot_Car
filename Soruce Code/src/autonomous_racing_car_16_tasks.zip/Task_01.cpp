// TASK 01 - ESP32-S3 BASIC SETUP
#include <Arduino.h>

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("TASK 01: ESP32-S3 BASIC SETUP");
    Serial.println("ESP32-S3 is running.");
}

void loop() {
    static unsigned long last = 0;
    if (millis() - last >= 1000) {
        last = millis();
        Serial.println("System OK");
    }
}

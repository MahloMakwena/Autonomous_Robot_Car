// TASK 14 - AUTOMATIC ACCELERATION / DECELERATION
#include <Arduino.h>

int speedPWM=80;
const int MIN_SPEED=80,MAX_SPEED=255,ACCEL=2,DECEL=8;
float frontDistance=200; bool turnAhead=false;

void controlSpeed(){
    if(frontDistance<=50){speedPWM=0;return;}
    if(frontDistance<=100 || turnAhead){speedPWM=max(MIN_SPEED,speedPWM-DECEL);return;}
    speedPWM=min(MAX_SPEED,speedPWM+ACCEL);
}
void setup(){Serial.begin(115200);Serial.println("TASK 14: Speed control");}
void loop(){
    static unsigned long last=0;
    if(millis()-last>=100){
        last=millis(); controlSpeed();
        Serial.printf("PWM: %d | Front: %.1f cm | Turn: %s\n",speedPWM,frontDistance,turnAhead?"YES":"NO");
    }
}

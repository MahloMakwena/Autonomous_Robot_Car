// TASK 15 - COMPLETE AUTONOMOUS DRIVE LOGIC
#include <Arduino.h>

float frontDistance=200,leftDistance=200,rightDistance=200;
bool emergencyStop=false,turnAhead=false;

void emergencyBrake(){Serial.println("EMERGENCY BRAKE");}
void avoidObstacle(){Serial.println(leftDistance>rightDistance?"AVOID LEFT":"AVOID RIGHT");}
void handleTurn(){Serial.println(leftDistance>rightDistance?"TURN LEFT":"TURN RIGHT");}
void normalDrive(){Serial.println("DRIVE FORWARD");}

void autonomousDrive(){
    if(emergencyStop){emergencyBrake();return;}
    if(frontDistance<=50){avoidObstacle();return;}
    if(turnAhead){handleTurn();return;}
    normalDrive();
}
void setup(){Serial.begin(115200);Serial.println("TASK 15: Autonomous-drive controller");}
void loop(){
    autonomousDrive();
    delay(500);
}

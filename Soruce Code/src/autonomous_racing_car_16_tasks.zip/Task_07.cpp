// TASK 07 - SPEED CALCULATION
#include <Arduino.h>

const int LE=14,RE=15; const float TPR=20.0, DIA=65.0;
const float CIRC=PI*DIA; volatile long lt=0,rt=0;
void IRAM_ATTR li(){lt++;} void IRAM_ATTR ri(){rt++;}

void setup(){
    Serial.begin(115200); pinMode(LE,INPUT_PULLUP);pinMode(RE,INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(LE),li,RISING);
    attachInterrupt(digitalPinToInterrupt(RE),ri,RISING);
    Serial.println("TASK 07: Speed test");
}
void loop(){
    static long pl=0,pr=0; static unsigned long last=millis();
    if(millis()-last>=100){
        unsigned long now=millis();
        noInterrupts(); long l=lt,r=rt; interrupts();
        long ticks=((l-pl)+(r-pr))/2; pl=l;pr=r;
        float metres=(ticks/TPR*CIRC)/1000.0;
        float kmh=metres/((now-last)/1000.0)*3.6;
        last=now;
        Serial.printf("Speed: %.2f km/h\n",kmh);
    }
}

// TASK 16 - FULL SYSTEM TEST
// This task is the integration stage.
// Integrate the individually tested modules only after each task passes.
#include <Arduino.h>

void setup(){
    Serial.begin(115200);
    Serial.println("======================================");
    Serial.println("TASK 16: FULL AUTONOMOUS CAR TEST");
    Serial.println("ESP32-S3 + RPLIDAR A1");
    Serial.println("Motors + Steering + Encoders + Buttons");
    Serial.println("======================================");
    Serial.println("Integration checklist:");
    Serial.println("1. Motors tested");
    Serial.println("2. Steering tested");
    Serial.println("3. Buttons and E-stop tested");
    Serial.println("4. Encoders tested");
    Serial.println("5. Distance tested");
    Serial.println("6. Speed tested");
    Serial.println("7. RPLIDAR communication verified");
    Serial.println("8. LiDAR angle/distance decoding verified");
    Serial.println("9. Obstacle detection verified");
    Serial.println("10. Avoidance verified");
    Serial.println("11. Turn detection verified");
    Serial.println("12. Steering verified");
    Serial.println("13. Speed control verified");
    Serial.println("Do not run the motors at speed until all safety tests pass.");
}
void loop(){
    static unsigned long last=0;
    if(millis()-last>=1000){last=millis();Serial.println("FULL SYSTEM READY FOR INTEGRATION TEST");}
}

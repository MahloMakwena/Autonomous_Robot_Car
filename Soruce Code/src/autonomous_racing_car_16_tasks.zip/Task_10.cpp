// TASK 10 - OBSTACLE DETECTION
#include <Arduino.h>

const float SAFE_DISTANCE_CM=50.0;
float frontDistance=999;

void detectObstacle(){
    if(frontDistance<=SAFE_DISTANCE_CM) Serial.println("OBSTACLE DETECTED");
    else Serial.println("PATH CLEAR");
}
void setup(){Serial.begin(115200);Serial.println("TASK 10: Obstacle detection");}
void loop(){
    // Replace this test value with the verified RPLIDAR front measurement.
    static bool test=false;
    frontDistance=test?40:120;
    detectObstacle();
    test=!test;
    delay(1000);
}

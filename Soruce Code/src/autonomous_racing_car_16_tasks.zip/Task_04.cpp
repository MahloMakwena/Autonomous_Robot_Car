// TASK 04 - POWER, START AND EMERGENCY STOP BUTTONS
#include <Arduino.h>

const int START_BUTTON=11, POWER_BUTTON=12, ESTOP_BUTTON=13;

void setup() {
    Serial.begin(115200);
    pinMode(START_BUTTON,INPUT_PULLUP);
    pinMode(POWER_BUTTON,INPUT_PULLUP);
    pinMode(ESTOP_BUTTON,INPUT_PULLUP);
    Serial.println("TASK 04: Button test");
}
void loop() {
    static int oldStart=HIGH, oldPower=HIGH, oldEstop=HIGH;
    int s=digitalRead(START_BUTTON), p=digitalRead(POWER_BUTTON), e=digitalRead(ESTOP_BUTTON);
    if(s==LOW && oldStart==HIGH) Serial.println("START button pressed");
    if(p==LOW && oldPower==HIGH) Serial.println("POWER button pressed");
    if(e==LOW && oldEstop==HIGH) Serial.println("EMERGENCY STOP pressed");
    oldStart=s; oldPower=p; oldEstop=e;
    delay(20);
}
